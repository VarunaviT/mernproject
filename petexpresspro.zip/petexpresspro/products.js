module.exports=[{
    animal:"dogs",
    prod:[
    {
        id:1,
        image:"images/dogbody1.webp",
        title:"Pet Head Ditch The Dirt Orange Shampoo For Dog - 300 ml",
        subtitle:"Tendulkar",
        price:"Sale price ₹1,424.05",
        
        },
        {
        id:2,
        image:"images/dogbody2.webp",
        title:"HUFT Natural Itch Relief Oatmeal Shampoo For Dogs - Apple Cider Vinegar & Aloe Vera",
        subtitle:"100% natural, pH-balanced itch relief dog shampoo",
        price:"Sale price ₹759.05",
        },
        {
        id:3,
        image:"images/dogbody3.webp",
        title:"Bubble Up - Small & Soft Puppy Shampoo - 200 ml",
        subtitle:"100% natural, pH-balanced itch relief dog shampoo",
        price:"Sale price ₹352.47",
        },
        
        {
        id:4,
        image:"images/dogbody4.webp",
        title:"Bio-Groom Fluffy Puppy Tear-Free Shampoo",
        subtitle:"100% natural, pH-balanced itch relief dog shampoo",
        price:"Sale price ₹1,282.50",
        },
         {
        id:5,
        image:"images/dogbody5.webp",
        title:"Isle of Dogs Everyday Lush Coating Dog Conditioner - Violet + Sea Mist - 500 ml",
        subtitle:"Protein-based, moisturising & easy to use",
        price:"Sale price ₹1,709.05",
        },
        {
        id:6,
        image:"images/dogacc1.webp",
        title:"Loveabowl Grain Free Chicken With Atlantic Lobster Gut-Friendly Dog Dry Food",
        subtitle:"Promotes healthy bones and is ideal for dogs with allergies.",
        price:"Sale price ₹1,399.00",
        
        },
        {
        id:7,
        image:"images/dogfood2.webp",
        title:"Pedigree PRO Expert Nutrition Senior (7+ Years) Adult Dog Dry Food",
        subtitle:" Formulated with high-quality ingredients",
        price:"Sale price ₹468.00",
        },
        {
        id:8,
        image:"images/dogfood3.webp",
        title:"Kennel Kitchen Chicken & Lamb Gourmet Loaf Wet Dog Food (All Breeds & Ages) - 185 g",
        subtitle:"Grain-free, preservative-free, natural & regionally-sourced",
        price:"Sale price ₹159.20",
        },
        
        {
        id:9,
        image:"images/dogfood4.webp",
        title:"Fidele+ Large Breed Puppy Dry Dog Food",
        subtitle:" For Optimum Growth & Development",
        price:"Sale price ₹675.00",
        },
         {
        id:10,
        image:"images/dogfood45webp.webp",
        title:"Little BigPaw Steamed Atlantic Salmon & Vegetables Terrine Wet Dog Food - 150 g",
        subtitle:"Grain-free, wheat-free, dairy-free & preservative-free",
        price:"Sale price  ₹210.00",
         }
]
},{
     animal:"cat",
     prod:[
    {
        id:11,
        image:"images/dogfood4.webp",
        title:"Fidele+ Large Breed Puppy Dry Dog Food",
        subtitle:" For Optimum Growth & Development",
        price:"Sale price ₹675.00",
        },
         {
        id:12,
        image:"images/dogfood45webp.webp",
        title:"Little BigPaw Steamed Atlantic Salmon & Vegetables Terrine Wet Dog Food - 150 g",
        subtitle:"Grain-free, wheat-free, dairy-free & preservative-free",
        price:"Sale price  ₹210.00",
         }
]

}]